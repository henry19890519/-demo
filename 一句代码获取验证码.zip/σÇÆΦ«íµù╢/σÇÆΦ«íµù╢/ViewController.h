//
//  ViewController.h
//  倒计时
//
//  Created by lanou3g on 16/1/5.
//  Copyright © 2016年 syx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

