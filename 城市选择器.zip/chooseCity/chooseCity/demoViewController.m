//
//  demoViewController.m
//  chooseCity
//
//  Created by sjq on 16/1/11.
//  Copyright © 2016年 SJQ. All rights reserved.
//
#define DeviceHeight            [[UIScreen mainScreen] bounds].size.height
#define DeviceWidth             [[UIScreen mainScreen] bounds].size.width
#define Key_DistrictSelectProvince          @"DistrictSelectProvince"
#define Key_DistrictSelectProvinceCode      @"DistrictSelectProvinceCode"
#define Key_DistrictSelectProvinceSubCode   @"DistrictSelectProvinceSubCode"
#define Key_DistrictSelectProvinceSub       @"DistrictSelectProvinceSub"
#define Key_DistrictSelectCityCode          @"DistrictSelectCityCode"
#define Key_DistrictSelectCity              @"DistrictSelectCity"

#import "demoViewController.h"

#import "GPDateView.h"


@interface demoViewController ()

@property (weak, nonatomic) IBOutlet UILabel *provinceLabel;
@property (weak, nonatomic) IBOutlet UILabel *cityLabel;
@property (weak, nonatomic) IBOutlet UILabel *areaLabel;

@end

@implementation demoViewController

- (void)viewDidLoad {
    [super viewDidLoad];



    self.view.backgroundColor = [UIColor yellowColor];
}

- (IBAction)chooseClick:(UIButton *)sender {
    
    GPDateView * dateView = [[GPDateView alloc] initWithFrame:CGRectMake(0, DeviceHeight-250, DeviceWidth, 250) Data:nil];
    
    [dateView showPickerView];
    
    dateView.ActionDistrictViewSelectBlock = ^(NSString *desStr,NSDictionary *selectDistrictDict){
        
        
        self.provinceLabel.text = [selectDistrictDict objectForKey:Key_DistrictSelectProvince];
        self.cityLabel.text = [selectDistrictDict objectForKey:Key_DistrictSelectCity];
        self.areaLabel.text = [selectDistrictDict objectForKey:Key_DistrictSelectProvinceSub];
        
    };
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
