//
//  XKPEActionSheetPicker.h
//  PestatePatient
//
//  Created by luliu on 15/11/11.
//  Copyright © 2015年 xikang. All rights reserved.
//

#import "AbstractActionSheetPicker.h"

@interface AbstractActionSheetPicker (Interface)

- (void)customizeInterface;

@end
