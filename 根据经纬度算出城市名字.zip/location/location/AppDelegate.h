//
//  AppDelegate.h
//  location
//
//  Created by WooY on 15/12/10.
//  Copyright © 2015年 WooY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

