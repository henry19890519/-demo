//
//  ViewController.m
//  location
//
//  Created by WooY on 15/12/10.
//  Copyright © 2015年 WooY. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
@interface ViewController ()

@property(nonatomic,strong)CLGeocoder *geocoder;
#pragma mark-地理编码
- (IBAction)geocode;
@property (weak, nonatomic) IBOutlet UITextField *addressField;
@property (weak, nonatomic) IBOutlet UILabel *longitudeLabel;
@property (weak, nonatomic) IBOutlet UILabel *latitudeLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailAddressLabel;

#pragma mark-反地理编码

- (IBAction)reverseGeocode;
@property (weak, nonatomic) IBOutlet UITextField *longitudeField;
@property (weak, nonatomic) IBOutlet UITextField *latitudeField;
@property (weak, nonatomic) IBOutlet UILabel *reverdeDetailAddressLabel;
@end

@implementation ViewController

#pragma mark-懒加载
-(CLGeocoder *)geocoder
{
    if (_geocoder==nil) {
        _geocoder=[[CLGeocoder alloc]init];
    }
    return _geocoder;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
}
/**
 *  地理编码：地名—>经纬度坐标
 */
- (IBAction)geocode {
    //1.获得输入的地址
    NSString *address=self.addressField.text;
    if (address.length==0) return;
    
    //2.开始地理编码
    //说明：调用下面的方法开始编码，不管编码是成功还是失败都会调用block中的方法
    [self.geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error) {
        //如果有错误信息，或者是数组中获取的地名元素数量为0，那么说明没有找到
        if (error || placemarks.count==0) {
            self.detailAddressLabel.text=@"你输入的地址没找到，可能在月球上";
        }else   //  编码成功，找到了具体的位置信息
        {
            //打印查看找到的所有的位置信息
            /*
             name:名称
             locality:城市
             country:国家
             postalCode:邮政编码
             */
            for (CLPlacemark *placemark in placemarks) {
                NSLog(@"name=%@ locality=%@ country=%@ postalCode=%@",placemark.name,placemark.locality,placemark.country,placemark.postalCode);
            }
            
            //取出获取的地理信息数组中的第一个显示在界面上
            CLPlacemark *firstPlacemark=[placemarks firstObject];
            //详细地址名称
            self.detailAddressLabel.text=firstPlacemark.name;
            //纬度
            CLLocationDegrees latitude=firstPlacemark.location.coordinate.latitude;
            //经度
            CLLocationDegrees longitude=firstPlacemark.location.coordinate.longitude;
            self.latitudeLabel.text=[NSString stringWithFormat:@"%.2f",latitude];
            self.longitudeLabel.text=[NSString stringWithFormat:@"%.2f",longitude];
        }
    }];
}

/**
 *  反地理编码：经纬度坐标—>地名
 */
- (IBAction)reverseGeocode {
    //1.获得输入的经纬度
    NSString *longtitudeText=self.longitudeField.text;
    NSString *latitudeText=self.latitudeField.text;
    if (longtitudeText.length==0||latitudeText.length==0) return;
    
    CLLocationDegrees latitude=[latitudeText doubleValue];
    CLLocationDegrees longitude=[longtitudeText doubleValue];
    
    CLLocation *location=[[CLLocation alloc]initWithLatitude:latitude longitude:longitude];
    //2.反地理编码
    [self.geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        if (error||placemarks.count==0) {
            self.reverdeDetailAddressLabel.text=@"你输入的地址没找到，可能在月球上";
        }else//编码成功
        {
            //显示最前面的地标信息
            CLPlacemark *firstPlacemark=[placemarks firstObject];
            //self.reverdeDetailAddressLabel.text=firstPlacemark.name;
            self.reverdeDetailAddressLabel.text=firstPlacemark.locality;
//            //经纬度
//            CLLocationDegrees latitude=firstPlacemark.location.coordinate.latitude;
//            CLLocationDegrees longitude=firstPlacemark.location.coordinate.longitude;
//            self.latitudeField.text=[NSString stringWithFormat:@"%.2f",latitude];
//            self.longitudeField.text=[NSString stringWithFormat:@"%.2f",longitude];
//            NSLog(@"%@",self.latitudeField.text);
        }
    }];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
@end
