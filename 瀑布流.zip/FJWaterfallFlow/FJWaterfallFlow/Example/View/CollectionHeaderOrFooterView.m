//
//  CollectionHeaderOrFooterView.m
//  FJWaterfallFlow
//
//  Created by fujin on 16/1/11.
//  Copyright © 2016年 fujin. All rights reserved.
//

#import "CollectionHeaderOrFooterView.h"

@implementation CollectionHeaderOrFooterView

@end
