//
//  CollectionViewCell.h
//  FJWaterfallFlow
//
//  Created by fujin on 16/1/8.
//  Copyright © 2016年 fujin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DataModel;
@interface CollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *picImageView;
@property (strong, nonatomic) IBOutlet UILabel *priceLabel;

- (void)setCellData:(DataModel *)dataModel;
@end
