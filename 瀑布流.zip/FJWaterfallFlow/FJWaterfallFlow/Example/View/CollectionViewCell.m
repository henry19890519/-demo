//
//  CollectionViewCell.m
//  FJWaterfallFlow
//
//  Created by fujin on 16/1/8.
//  Copyright © 2016年 fujin. All rights reserved.
//

#import "CollectionViewCell.h"
#import "UIImageView+WebCache.h"
#import "DataModel.h"
@implementation CollectionViewCell

- (void)setCellData:(DataModel *)dataModel{
    [self.picImageView sd_setImageWithURL:[NSURL URLWithString:dataModel.img]];
    self.priceLabel.text = dataModel.price;
}
@end
