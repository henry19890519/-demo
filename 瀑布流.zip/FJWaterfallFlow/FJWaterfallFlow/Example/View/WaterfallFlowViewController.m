//
//  WaterfallFlowViewController.m
//  FJWaterfallFlow
//
//  Created by fujin on 16/1/8.
//  Copyright © 2016年 fujin. All rights reserved.
//

#import "WaterfallFlowViewController.h"
#import "CollectionViewCell.h"
#import "CollectionHeaderOrFooterView.h"
#import "WaterFallFlowViewModel.h"
#import "FJWaterfallFlowLayout.h"
#import "DataModel.h"

@interface WaterfallFlowViewController ()<FJWaterfallFlowLayoutDelegate>
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) WaterFallFlowViewModel *viewModel;
@end

@implementation WaterfallFlowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Waterfall flow";
    
    [self configCollectionView];
    
    self.viewModel = [[WaterFallFlowViewModel alloc] init];
    [self.viewModel getData];
    
    [self.collectionView reloadData];
}

- (void)configCollectionView{
    //waterFallFlow
    FJWaterfallFlowLayout *fjWaterfallFlowLayout = [[FJWaterfallFlowLayout alloc] init];
    fjWaterfallFlowLayout.itemSpacing = 10;
    fjWaterfallFlowLayout.lineSpacing = 10;
    fjWaterfallFlowLayout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    fjWaterfallFlowLayout.colCount = 3;
    fjWaterfallFlowLayout.delegate = self;
    self.collectionView.collectionViewLayout = fjWaterfallFlowLayout;
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"ReuseView" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"sectionHeader"];
    [self.collectionView registerNib:[UINib nibWithNibName:@"ReuseView" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"sectionFooter"];
}

#pragma mark collectionViewDatasouce
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return self.viewModel.dataArray.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.viewModel.dataArray[section] count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CollectionViewCell" forIndexPath:indexPath];
    [cell setCellData:self.viewModel.dataArray[indexPath.section][indexPath.item]];
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        CollectionHeaderOrFooterView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"sectionHeader" forIndexPath:indexPath];
        
        headerView.title.text = [NSString stringWithFormat:@"header__%@",self.viewModel.nameArray[indexPath.section]];
        return headerView;
    }else{
        CollectionHeaderOrFooterView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"sectionFooter" forIndexPath:indexPath];
        
        footerView.title.text = [NSString stringWithFormat:@"footer__%@",self.viewModel.nameArray[indexPath.section]];
        return footerView;
    }
}

#pragma mark FJWaterfallFlowLayoutDelegate
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(FJWaterfallFlowLayout*)collectionViewLayout heightForWidth:(CGFloat)width atIndexPath:(NSIndexPath*)indexPath
{
    DataModel * model = self.viewModel.dataArray[indexPath.section][indexPath.item];
    return model.h/model.w*width;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(FJWaterfallFlowLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return CGSizeMake(CGRectGetWidth(self.view.frame) - 20, 20);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(FJWaterfallFlowLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section{
    return CGSizeMake(CGRectGetWidth(self.view.frame) - 20, 20);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
