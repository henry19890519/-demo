//
//  WaterFallFlowViewModel.h
//  FJWaterfallFlow
//
//  Created by fujin on 16/1/8.
//  Copyright © 2016年 fujin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WaterFallFlowViewModel : NSObject
@property (strong, nonatomic) NSArray *dataArray;
@property (strong, nonatomic) NSArray *nameArray;
- (void)getData;
@end
